#!/usr/bin/env python3
import gi
import random
import os

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk, Pango

class FrasesApp(Gtk.Window):
    def __init__(self):
        super().__init__(title="Frases Bonitas 💖")
        self.set_border_width(20)
        self.set_default_size(500, 300)

        # Icono
        icon_path = os.path.join(os.path.dirname(__file__), "icono.png")
        if os.path.exists(icon_path):
            try:
                self.set_icon_from_file(icon_path)
            except Exception:
                pass

        # Lista de frases
        self.frases = [
            "Cree en ti y todo será posible.",
            "Cada día es una nueva oportunidad.",
            "Lo mejor está por venir.",
            "Nunca es tarde para comenzar de nuevo.",
            "Sonríe, la vida es bella.",
            "Hazlo con pasión o no lo hagas.",
            "Tu esfuerzo de hoy será tu éxito de mañana.",
            "Cambia tus pensamientos y cambiarás tu mundo.",
            "Todo logro comienza con la decisión de intentarlo.",
            "No cuentes los días, haz que los días cuenten.",
            "Sé la energía que quieres atraer.",
            "El éxito es la suma de pequeños esfuerzos diarios.",
            "Cree en la magia de los nuevos comienzos.",
            "Haz lo que puedas, con lo que tengas, donde estés.",
            "El único límite eres tú.",
            "Nunca dejes de soñar.",
            "La actitud lo es todo.",
            "Pequeños pasos llevan a grandes destinos.",
            "Hoy es un buen día para sonreír.",
            "Aprende a disfrutar el viaje.",
            "Persigue tus sueños sin miedo.",
            "Cada día es una nueva página de tu historia.",
            "Si puedes soñarlo, puedes lograrlo.",
            "Sé fuerte, las cosas mejorarán.",
            "Todo esfuerzo tiene su recompensa.",
            "Tu luz interior nunca se apaga.",
            "Siempre hay algo por lo que agradecer.",
            "Haz que hoy cuente.",
            "Confía en el proceso.",
            "Tu potencial es infinito."
        ]

        # Contenedor principal
        vbox = Gtk.Box(orientation=Gtk.Orientation.VERTICAL, spacing=20)
        vbox.set_margin_top(20)
        vbox.set_margin_bottom(20)
        vbox.set_margin_start(20)
        vbox.set_margin_end(20)
        self.add(vbox)

        # Botón principal
        self.boton = Gtk.Button(label="💌 ¿Quieres leer algo bonito?")
        self.boton.get_child().modify_font(Pango.FontDescription("Sans Bold 16"))
        self.boton.connect("clicked", self.mostrar_frase)
        vbox.pack_start(self.boton, False, False, 0)

        # Etiqueta de frase
        self.label = Gtk.Label(label="Presiona el botón para leer algo bonito")
        self.label.set_line_wrap(True)
        self.label.set_justify(Gtk.Justification.CENTER)
        self.label.modify_font(Pango.FontDescription("Sans 16"))
        vbox.pack_start(self.label, True, True, 0)

    def mostrar_frase(self, widget):
        frase = random.choice(self.frases)
        self.label.set_text(frase)

if __name__ == "__main__":
    win = FrasesApp()
    win.connect("destroy", Gtk.main_quit)
    win.show_all()
    Gtk.main()
